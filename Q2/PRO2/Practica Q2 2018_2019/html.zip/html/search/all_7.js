var searchData=
[
  ['lcodis',['lcodis',['../class_idioma.html#ab908f7375f4506b26dd3cd163bc0b8cd',1,'Idioma']]],
  ['lee_5fidioma',['lee_idioma',['../class_idioma.html#a0a4599da90aef15aa798a63ee6ad820e',1,'Idioma']]]
];
