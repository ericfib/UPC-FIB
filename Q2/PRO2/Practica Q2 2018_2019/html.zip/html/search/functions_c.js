var searchData=
[
  ['tabfreq',['TabFreq',['../class_tab_freq.html#a0e429dc751718b7fc1c6ad3e127a0f98',1,'TabFreq::TabFreq()'],['../class_tab_freq.html#a9080ea66c71746520f33a542e56dabb0',1,'TabFreq::TabFreq(const TabFreq &amp;tf)']]],
  ['tabla',['tabla',['../class_idioma.html#a862b9fe26b8929a7d6b4af8a1373d0a0',1,'Idioma']]],
  ['tree_5fin',['tree_in',['../class_idioma.html#a1fdf7b5bae642b911ab51b100f56e55f',1,'Idioma']]],
  ['tree_5fpre',['tree_pre',['../class_idioma.html#aaf85e226b876366ea2cb1ebf5cf04388',1,'Idioma']]]
];
