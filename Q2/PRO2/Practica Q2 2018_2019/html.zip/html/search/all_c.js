var searchData=
[
  ['sethojas',['sethojas',['../class_idioma.html#aa4a86dd82c04a280b32d98c775cf5eda',1,'Idioma']]]
];
