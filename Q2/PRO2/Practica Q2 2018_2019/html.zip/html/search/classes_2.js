var searchData=
[
  ['tabfreq',['TabFreq',['../class_tab_freq.html',1,'']]]
];
