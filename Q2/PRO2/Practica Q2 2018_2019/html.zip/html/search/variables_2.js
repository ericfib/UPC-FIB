var searchData=
[
  ['taula',['taula',['../class_idioma.html#a5e144ffaa4c1c63690e08e4e2687a13f',1,'Idioma']]],
  ['tf',['TF',['../class_tab_freq.html#ae6be9a9671af1d897960648e10a62cfb',1,'TabFreq']]],
  ['treecode',['treecode',['../class_idioma.html#a5eeaf73b2498503c5c686ac259e1f675',1,'Idioma']]]
];
