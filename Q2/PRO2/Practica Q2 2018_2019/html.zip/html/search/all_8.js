var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modifica',['modifica',['../class_tab_freq.html#a78f5e7e73648d2a7ecc0bd28f4cbd4c0',1,'TabFreq']]],
  ['modificaridioma',['modificaridioma',['../class_idioma.html#ad29b4c109c3fd61d7753c3345c438694',1,'Idioma']]]
];
