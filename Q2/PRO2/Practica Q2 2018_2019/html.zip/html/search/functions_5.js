var searchData=
[
  ['idioma',['Idioma',['../class_idioma.html#a6722a621ce03825772493e67e5a17215',1,'Idioma']]],
  ['ini_5fdecodifica',['ini_decodifica',['../class_idioma.html#a797cfc4dd3d423c41f46926a68410992',1,'Idioma']]],
  ['inici',['inici',['../class_tab_freq.html#a4c139f7774cf70aa67d354f7f4d3ae87',1,'TabFreq']]]
];
