var searchData=
[
  ['fi',['fi',['../class_tab_freq.html#acaa682bda54944915db86e012756cef8',1,'TabFreq']]]
];
