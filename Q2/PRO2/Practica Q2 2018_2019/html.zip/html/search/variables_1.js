var searchData=
[
  ['lcodis',['lcodis',['../class_idioma.html#ab908f7375f4506b26dd3cd163bc0b8cd',1,'Idioma']]]
];
