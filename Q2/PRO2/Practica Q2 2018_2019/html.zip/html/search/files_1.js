var searchData=
[
  ['idioma_2ecc',['idioma.cc',['../idioma_8cc.html',1,'']]],
  ['idioma_2ehh',['idioma.hh',['../idioma_8hh.html',1,'']]]
];
