var searchData=
[
  ['lee_5fidioma',['lee_idioma',['../class_idioma.html#a0a4599da90aef15aa798a63ee6ad820e',1,'Idioma']]]
];
