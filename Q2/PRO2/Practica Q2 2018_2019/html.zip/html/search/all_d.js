var searchData=
[
  ['tabfreq',['TabFreq',['../class_tab_freq.html',1,'TabFreq'],['../class_tab_freq.html#a0e429dc751718b7fc1c6ad3e127a0f98',1,'TabFreq::TabFreq()'],['../class_tab_freq.html#a9080ea66c71746520f33a542e56dabb0',1,'TabFreq::TabFreq(const TabFreq &amp;tf)']]],
  ['tabfreq_2ecc',['TabFreq.cc',['../_tab_freq_8cc.html',1,'']]],
  ['tabfreq_2ehh',['TabFreq.hh',['../_tab_freq_8hh.html',1,'']]],
  ['tabla',['tabla',['../class_idioma.html#a862b9fe26b8929a7d6b4af8a1373d0a0',1,'Idioma']]],
  ['taula',['taula',['../class_idioma.html#a5e144ffaa4c1c63690e08e4e2687a13f',1,'Idioma']]],
  ['tf',['TF',['../class_tab_freq.html#ae6be9a9671af1d897960648e10a62cfb',1,'TabFreq']]],
  ['tree_5fin',['tree_in',['../class_idioma.html#a1fdf7b5bae642b911ab51b100f56e55f',1,'Idioma']]],
  ['tree_5fpre',['tree_pre',['../class_idioma.html#aaf85e226b876366ea2cb1ebf5cf04388',1,'Idioma']]],
  ['treecode',['treecode',['../class_idioma.html#a5eeaf73b2498503c5c686ac259e1f675',1,'Idioma']]]
];
