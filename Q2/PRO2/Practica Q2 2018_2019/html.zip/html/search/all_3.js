var searchData=
[
  ['decodifica',['decodifica',['../class_idioma.html#a225fb55a6732d07e61bf310f5f29aa0e',1,'Idioma']]],
  ['decodifica_5fi',['decodifica_I',['../class_cjt__idiomas.html#a99a44238cc4b83392ff1991ad1319c46',1,'Cjt_idiomas']]]
];
