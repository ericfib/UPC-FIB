var searchData=
[
  ['operator_3c',['operator&lt;',['../idioma_8cc.html#ae4068cab7e1ad43a8d03f2f5d50e06df',1,'idioma.cc']]]
];
