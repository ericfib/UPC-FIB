var searchData=
[
  ['afegir_5fmod_5fidioma',['afegir_mod_idioma',['../class_cjt__idiomas.html#a1e38b16ba4bb49a91589c85ec7775a5f',1,'Cjt_idiomas']]]
];
