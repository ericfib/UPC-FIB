var searchData=
[
  ['read_5fconjunto',['read_conjunto',['../class_cjt__idiomas.html#a09e45083b9df57c02f05bda0bef3d0d3',1,'Cjt_idiomas']]],
  ['read_5ftab',['read_tab',['../class_tab_freq.html#aa84cb3ed7c4958be0bfe4fbd8c6c0e6a',1,'TabFreq']]]
];
