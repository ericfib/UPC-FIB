var searchData=
[
  ['buscacodi',['buscacodi',['../class_idioma.html#a23589aa5ba65f484e2477ed611ce151f',1,'Idioma']]]
];
